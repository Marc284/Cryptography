/**
 * 
 */
package crypto;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

/**
 * @author tosindo
 *
 */
public class Client implements IParent {
	
	public static void main(String[] args){
		Client client = new Client();
		client.sendAndReceice();
		byte[] message = "Test message".getBytes();
		client.encryptMessage(message);
		client.decryptMessage(client.encryptMessage(message));
	}
	
	public void sendAndReceice() {
		Socket client;
	    ObjectOutputStream oos;
	    ObjectInputStream ois;
	    
	    try {
	    	client = new Socket("localhost",PORT);
			
	    	System.out.println("Connected to Server on "+ client.getInetAddress());

	    	oos = new ObjectOutputStream(client.getOutputStream());
	    	ois = new ObjectInputStream(client.getInputStream());
	    	
	    	// send a plaintext message to server
	    	String plaintxt = "Hello from client";
	    	
	    	// send message to server
	    	oos.writeObject(plaintxt.getBytes());
	    	oos.flush();
	    	
	    	// receive response from server
	    	byte[] response = (byte[]) ois.readObject();
	    	
	    	System.out.println("Response from server: "+ new String(response, "ASCII"));
	    	
	    	// close cliet socket
	    	client.close();
	    	ois.close();
	    	oos.close();
	    	
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public byte[] encryptMessage(byte[] plaintext) {
		
		  byte[] encryptedMessage = null;
		
		try{

			//Generate Key
		    KeyGenerator keygenerator = KeyGenerator.getInstance("DES");
		    SecretKey desKey = keygenerator.generateKey();
		    
		    //Create Cipher
		    Cipher desCipher;
		    desCipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
		    //Initialize Cipher
		    desCipher.init(Cipher.ENCRYPT_MODE, desKey);
		    
		    //Encrypt Message
		    encryptedMessage = desCipher.doFinal(plaintext);

		    System.out.println("Message : " + new String(plaintext));
		    System.out.println("Message in BYTE: " + plaintext);
		    System.out.println("Message Encryted : " + encryptedMessage); 
		    	    
		}catch(NoSuchAlgorithmException e){
			e.printStackTrace();
		}catch(NoSuchPaddingException e){
			e.printStackTrace();
		}catch(InvalidKeyException e){
			e.printStackTrace();
		}catch(IllegalBlockSizeException e){
			e.printStackTrace();
		}catch(BadPaddingException e){
			e.printStackTrace();
		} 
		
		return encryptedMessage;	
	}

	@Override
	public byte[] decryptMessage(byte[] ciphertext) {
		
		 byte[] decryptedMessage = null;
		
		try {	
		Cipher desCipher;
		desCipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
		
	    desCipher.init(Cipher.DECRYPT_MODE, /*key*/);

	    // Decrypt the text
	    decryptedMessage = desCipher.doFinal(ciphertext);
	    
	    System.out.println("Text Decryted : " + new String(decryptedMessage));
	    
		}catch(NoSuchAlgorithmException e){
			e.printStackTrace();
		}catch(InvalidKeyException e){
			e.printStackTrace();
		}catch(IllegalBlockSizeException e){
			e.printStackTrace();
		}catch(BadPaddingException e){
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} 
		
		return decryptedMessage;
	}

}
