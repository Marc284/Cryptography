/**
 * 
 */
package crypto;

/**
 * @author tosindo
 *
 */
public class Utility {
	
	// implement your Affine encryption/decryption function here
	
	// implement your Hill enryption/decryption function here
}
